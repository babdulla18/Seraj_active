function sayHello() {
  alert("Hi there! You clicked the button.");
}